
import 'package:flutter/material.dart';

import '../workspace/workspace.dart';

import 'theme.dart';



class DaraStudioApp extends StatelessWidget {


  const DaraStudioApp({

    super.key,

  });



  @override

  Widget build(BuildContext context) {


    return MaterialApp(

      title: "Dara Studio",


      debugShowCheckedModeBanner: false,


      theme: AppTheme.dark,


      home: const Workspace(),


    );


  }


}
