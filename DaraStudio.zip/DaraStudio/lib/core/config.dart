
class AppConfig {

  static const String name =
      "Dara Studio";


  static const String version =
      "1.0.0";


  static const bool offlineFirst =
      true;

}
