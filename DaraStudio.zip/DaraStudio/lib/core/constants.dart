
import 'package:flutter/material.dart';


class AppConstants {


  static const Color background =
      Color(0xFF0D1117);


  static const Color panel =
      Color(0xFF161B22);


  static const double sidebarWidth =
      260;


}
