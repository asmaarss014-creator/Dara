
import 'state.dart';


class AppController {


  final AppState state =
      AppState();



  void openProject(String path){

    state.currentProject =
        path;

  }


}
