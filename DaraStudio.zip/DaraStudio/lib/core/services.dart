
class ServiceContainer {


  final Map<Type, dynamic> services =
      {};


  void register<T>(T value){

    services[T] = value;

  }


}
