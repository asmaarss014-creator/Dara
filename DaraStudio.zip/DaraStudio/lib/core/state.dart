
class AppState {


  String currentProject = "";


  String currentFile = "";


  bool terminalOpen = true;



}
