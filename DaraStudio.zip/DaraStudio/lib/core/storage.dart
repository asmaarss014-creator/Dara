
class StorageService {


  Future<void> save(
      String key,
      String value
  ) async {

  }



  Future<String?> read(
      String key
  ) async {

    return null;

  }


}
