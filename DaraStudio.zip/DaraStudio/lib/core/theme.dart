
import 'package:flutter/material.dart';

import 'constants.dart';


class AppTheme {


  static ThemeData dark = ThemeData(

    brightness:
        Brightness.dark,


    scaffoldBackgroundColor:
        AppConstants.background,


  );


}
