
class CodeEditor {


  String content = "";


  void write(String value){

    content = value;

  }


  String read(){

    return content;

  }


}
