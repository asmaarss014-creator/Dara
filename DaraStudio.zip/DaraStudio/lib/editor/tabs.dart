
class EditorTabs {


  final List<String> tabs = [];


  void open(String file){

    tabs.add(file);

  }


}
