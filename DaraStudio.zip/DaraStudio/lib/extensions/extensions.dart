
class Extensions {


  List<String> installed = [];


  void install(String name){

    installed.add(name);

  }


}
