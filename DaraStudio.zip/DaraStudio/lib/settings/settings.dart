
class Settings {


  bool darkMode = true;


  String fontFamily =
      "JetBrains Mono";


}
