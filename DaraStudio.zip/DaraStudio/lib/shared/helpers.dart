
class Helpers {


  static String cleanPath(
      String path
  ){

    return path.trim();

  }


}
