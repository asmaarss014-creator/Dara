
import 'package:flutter/material.dart';



class DaraCard extends StatelessWidget {


  final Widget child;


  const DaraCard({

    super.key,

    required this.child,

  });



  @override

  Widget build(BuildContext context){


    return Card(

      child: child,

    );


  }


}
