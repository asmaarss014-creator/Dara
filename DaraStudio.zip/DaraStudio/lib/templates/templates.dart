
class Templates {


  List<String> available = [

    "Flutter",

    "Python",

    "HTML"

  ];


}
