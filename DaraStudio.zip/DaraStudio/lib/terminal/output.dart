
class TerminalOutput {


  final List<String> lines = [];


  void add(String text){

    lines.add(text);

  }


}
