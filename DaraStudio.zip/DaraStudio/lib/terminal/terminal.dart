
class Terminal {


  List<String> history = [];


  void execute(String command){

    history.add(command);

  }


}
