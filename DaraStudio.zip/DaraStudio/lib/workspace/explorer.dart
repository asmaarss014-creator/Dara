
class Explorer {


  List<String> files = [];


  void addFile(String file){

    files.add(file);

  }


}
