
import 'package:flutter/material.dart';



class Workspace extends StatelessWidget {


  const Workspace({

    super.key,

  });



  @override

  Widget build(BuildContext context) {


    return Scaffold(

      body: Center(

        child: Text(

          "Dara Studio Workspace",

        ),

      ),

    );


  }


}
